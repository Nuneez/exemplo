function(){
	var tinta = document.querySelector("#tinta")
	tinta.addEventListener("change",mudarCor)
}

function(){
	var tinta = document.querySelector("#tinta")
	car cor = tinta.value
	console.log(cor)
}


window.addEventListener("load", iniciar)